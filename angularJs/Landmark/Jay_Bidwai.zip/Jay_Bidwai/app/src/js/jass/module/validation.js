/**
 * A seprate validation module for application
 *
 **/

(function(){

	angular.module('tangoValidation',[]);

})();