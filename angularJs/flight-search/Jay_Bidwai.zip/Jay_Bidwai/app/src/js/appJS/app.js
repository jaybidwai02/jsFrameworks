
var app = angular.module('FlightSearch',['rzModule']);

