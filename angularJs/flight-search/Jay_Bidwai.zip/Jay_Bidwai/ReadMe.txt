/** 
  * Name: Jay Bidwai
  *
*/

To Run Test Case You need to insatll dependencies - 

To install dependencies-
run -> npm install
and
run -> npm install -g karma-cli

To run Test Case
run -> karma start karma.conf.js


What I Covered In This POC

1. Unit Test -
	
	I wrote 9 test case to ensure application in running fine.

	Test cases are divided in -

	A. Initialization
	B. Action handler in controller
	C. Service function call -
			** used Spies(spyOn) of jasmine to check service function is being called or not.
			** used Spies(spyOn) of jasmine to check service function return value.


2. Logical Sepration of code

3. Easy to understand logical code.

4. Structural placement of code

5. Comments are present in code to help to understand task of function


