

describe('hello world', () => {
  it('works', () => {
    expect(true).to.be.true;
  });
});
