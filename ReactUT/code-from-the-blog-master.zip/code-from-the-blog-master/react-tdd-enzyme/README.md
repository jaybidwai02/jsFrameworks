# React TDD Enzyme
-

A sample working boilerplate on how to set up a testing suite with Webpack, React, Mocha, Chai and enzyme.

1) Install the dependencies with `npm install`
2) Run the tests either once (`npm run test`) on in TDD mode (`npm run test:watch`)

Follow along the tutorial on the blog post:
